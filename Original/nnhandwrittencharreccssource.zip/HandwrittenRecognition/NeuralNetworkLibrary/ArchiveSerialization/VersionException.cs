using System;
using System.Collections.Generic;
using System.Text;

namespace ArchiveSerialization
{
	/// <summary>
	///  Handles exceptions for the serialization of the wrong version
	/// </summary>
	public class VersionException : System.SystemException
	{

	}
}
