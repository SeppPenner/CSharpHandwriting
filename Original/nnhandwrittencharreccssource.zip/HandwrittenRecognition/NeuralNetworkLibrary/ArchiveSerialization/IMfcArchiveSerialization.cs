using System;


namespace ArchiveSerialization
{
	public interface IMfcArchiveSerialization
	{
		void Serialize(MfcArchive ar);

	}
}
