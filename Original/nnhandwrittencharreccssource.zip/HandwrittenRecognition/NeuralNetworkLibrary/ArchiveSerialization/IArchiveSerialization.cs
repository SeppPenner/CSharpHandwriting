using System;


namespace ArchiveSerialization
{
	public interface IArchiveSerialization
	{
		void Serialize(Archive ar);

	}
}
